tst_05<LISA><props><version>6.2.0.620</version><user>A.Baumann</user><date>43964.5525106134</date><kommentar visible="False" font="Arial,-16,clBlack," left="0" top="10"></kommentar></props><LSATestData><version>4</version><lsatestdat><pp><ppattr p2="LSA Test"></ppattr></pp>
<stivli>
<stivta><stivze id="0" dt="43959" did="99" akt="False" mazl="60" mibel="30" mabel="40"></stivze><stivze id="1" dt="43959" did="100" akt="False" mibel="30" mabel="40"></stivze><stivze id="2" dt="43959" did="101" akt="False" mibel="20" mabel="30"></stivze><stivze id="3" dt="43959" did="102" akt="False" mibel="20" mabel="30"></stivze><stivze id="4" dt="43959" did="104" akt="False"></stivze><stivze id="5" dt="41257" did="5" mizl="60" mazl="1200" mibel="5" mabel="5"></stivze><stivze id="6" dt="41257" did="6" mizl="60" mazl="1200" mibel="5" mabel="5"></stivze><stivze id="7" dt="41257" did="7" mizl="60" mazl="1200" mibel="5" mabel="5"></stivze><stivze id="8" dt="41257" did="8" mizl="60" mazl="1200" mibel="5" mabel="5"></stivze><stivze id="9" dt="41257" did="9" mizl="200" mazl="1200" mibel="5" mabel="5"></stivze><stivze id="10" dt="41257" did="10" mizl="200" mazl="1200" mibel="5" mabel="5"></stivze><stivze id="11" dt="41257" did="11" mizl="200" mazl="1200" mibel="5" mabel="5"></stivze><stivze id="48" dt="42922" did="84" mizl="200" mazl="300"></stivze><stivze id="49" dt="42922" did="85" mizl="200" mazl="300"></stivze><stivze id="50" dt="42922" did="86" mizl="200" mazl="300"></stivze><stivze id="51" dt="42922" did="87" mizl="200" mazl="300"></stivze><stivze id="52" dt="42922" did="88" mizl="200" mazl="300"></stivze><stivze id="53" dt="42922" did="89" mizl="200" mazl="300"></stivze><stivze id="54" dt="42922" did="90" mizl="200" mazl="300"></stivze><stivze id="55" dt="42922" did="91" mizl="200" mazl="300"></stivze><stivze id="56" dt="42922" did="92" mizl="200" mazl="300"></stivze><stivze id="63" dt="42922" did="93" mizl="200" mazl="300"></stivze><stivze id="64" dt="42922" did="94" mizl="200" mazl="300"></stivze><stivze id="0" dt="41257" did="0" mizl="150" mazl="600" mibel="5" mabel="50"></stivze><stivze id="1" dt="41257" did="1" mizl="200" mazl="600" mibel="5" mabel="50"></stivze><stivze id="2" dt="41257" did="2" mizl="200" mazl="600" mibel="5" mabel="50"></stivze><stivze id="3" dt="41257" did="3" mizl="250" mazl="600" mibel="5" mabel="50"></stivze><stivze id="27" dt="43959" did="96" mizl="300" mazl="400"></stivze><stivze id="28" dt="43959" did="103" mizl="300" mazl="400"></stivze><stivze id="29" dt="43959" did="97" mizl="300" mazl="350"></stivze><stivze id="30" dt="43959" did="98" mizl="350" mazl="400"></stivze><stivtaat liid="64" name="IV-Zufallsmuster 1"></stivtaat>
</stivta>
<pp><ppattr p2="Zufall IV"></ppattr></pp>
</stivli>
<stovli>
<stovta><stovtaat name="&#xD6;V-Zufallsmuster 1"></stovtaat>
</stovta>
<pp><ppattr p2="Zufall &#xD6;V"></ppattr></pp>
</stovli>
<umtest>
<umteta><umteze id="115" dt="43964" tw1="10" tw2="10" spl="1"></umteze><umteze id="116" dt="43964" sid="60" tw1="60" tw2="2400" spl="1" fzs="1" va="1" iv="1"></umteze><umteze id="117" dt="43964" sid="59" tw1="72" tw2="2400" spl="1" fzs="1" va="1" iv="1"></umteze><umteze id="118" dt="43964" sid="57" tw1="90" tw2="2400" spl="1" fzs="1" va="1" iv="1"></umteze><umteze id="119" dt="43964" sid="62" tw1="100" tw2="2400" spl="1" fzs="1" va="1" iv="1"></umteze><umtetaat liid="119" name="Umschaltmuster 1" eben="1"></umtetaat>
</umteta>
<pp><ppattr p2="Umschalttest-Parametrierung"></ppattr></pp>
</umtest>
<temu>
<temuze><temuzeat name="Testmuster 1" oevzu="False"></temuzeat><temuz zeit="-1" tx="-1" id="-2" szpid="-1"></temuz>
</temuze><curr>0</curr>
<pp><ppattr p2="Testmuster"></ppattr></pp>
</temu>
<testsz><teszze id="39" dt="43964" name="Szenario1" namu="Umschaltmuster 1" nami="IV-Zufallsmuster 1" umba="1" ende="3" endti="9999999"></teszze><teszat liid="40"></teszat>
<pp><ppattr p2="Test-Szenarien"></ppattr></pp>
</testsz></lsatestdat></LSATestData></LISA>